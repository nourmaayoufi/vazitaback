package vazita.config;

public class WebConfig {

}
