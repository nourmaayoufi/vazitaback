package vazita.service;

public class InspectionService {

}
