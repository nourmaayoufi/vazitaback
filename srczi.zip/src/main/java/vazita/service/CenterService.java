package vazita.service;

public class CenterService {

}
