package vazita.exception;

public class ResourceNotFoundException {

}
