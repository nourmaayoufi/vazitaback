package vazita.exception;

public class ValidationException {

}
