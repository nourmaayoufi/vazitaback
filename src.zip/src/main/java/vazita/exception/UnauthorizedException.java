package vazita.exception;

public class UnauthorizedException {

}
