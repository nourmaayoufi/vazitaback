package vazita.security;

public class CenterPermissionEvaluator {

}
