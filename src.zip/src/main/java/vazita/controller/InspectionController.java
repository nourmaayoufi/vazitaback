package vazita.controller;

public class InspectionController {

}
