package vazita.service;

public class AnalyticsService {

}
